#include <stdio.h>
#define MAX_TITLE_SIZE 20

//Type the struct here
struct Book {
	int isbn;
	float price;
	int year;
	int qty;
	char title[MAX_TITLE_SIZE];
};

//Type the function prototypes here
void menu();
void displayInventory(const char filename[]);
void addBook(const char filename[], struct Book *b2Add);
void checkPrice(const char filename[], const int isbn2find);
int searchInventory(FILE *fp, const int isbn2find);
float calculateCapital(const char filename[]);
int readRecord(FILE *fp, struct Book *b2read);


int main()
{
	//Type your code here:
	struct Book mybook = { 0 }; // struct book object
	char filename[] = "inventory.txt"; // Name of the file
	int option;
	int input;

	printf("Welcome to the Book Store\n");
	printf("=========================\n");

	do {
		menu();

		printf("Select: ");
		scanf("%d", &option);

		switch (option) {
		case 0:
			printf("Goodbye!\n");
			break;
		case 1:
			displayInventory(filename);
			break;
		case 2:
			printf("ISBN:");
			scanf("%d", &mybook.isbn);
			printf("Title:");
			scanf(" %20[^\n]", &mybook.title);
			printf("Year:");
			scanf("%d", &mybook.year);
			printf("Price:");
			scanf("%f", &mybook.price);
			printf("Quantity:");
			scanf("%d", &mybook.qty);
			addBook(filename, &mybook);
			break;
		case 3:
			printf("Please input the ISBN number of the book:\n\n");
			scanf("%d", &input);
			checkPrice(filename, input);
			break;
		case 4:
			printf("The total capital is: $%.2f\n", calculateCapital(filename));
			break;
		default:
			menu();
			break;
		}
	} while (option != 0);

	return 0;
}

void menu()
{
	printf("Please select from the following options:\n");
	printf("1) Display the inventory.\n");
	printf("2) Add a book to the inventory.\n");
	printf("3) Check price.\n");
	printf("4) Calculate total capital of the store.\n");
	printf("0) Exit.\n\n");
}

void displayInventory(const char filename[])
{
	//Define an object of struct Book
	struct Book books;
	int i = 0;

	//Open the file, and check for null pointer
	FILE *fp = NULL;
	fp = fopen(filename, "r");

	//If the file is properly opened, display headers, similar to workshop 8
	if (fp != NULL) {

		printf("\n\nInventory\n");
		for (i = 0; i < 51; i++) {
			printf("=");
		}
		printf("\n");
		printf("ISBN      Title               Year Price  Quantity\n");
		printf("---------+-------------------+----+-------+--------\n");
		rewind(fp);

		while ((readRecord(fp, &books)) == 5) {
			printf("%-10d%-20s%-5d$%-8.2f%-8d", books.isbn, books.title, books.year, books.price, books.qty);
			printf("\n");
		}
		fclose(fp);
	}


	//Display the footer
	for (i = 0; i < 51; i++) {
		printf("=");
	}
	printf("\n\n");

	//Close the file
}

void addBook(const char filename[], struct Book *b2Add)
{	//temporary variables

	//Open the file for appending (a+)
	FILE *fp = NULL;
	fp = fopen(filename, "a+");

	if (fp != NULL) {
		if (searchInventory(fp, b2Add->isbn) == 1) {
			printf("The book exists in the repository!\n");
		}
		else {
			fprintf(fp, "\n%d;%.2f;%d;%d;%s\n", b2Add->isbn, b2Add->price, b2Add->year, b2Add->qty, b2Add->title);
			printf("The book is successfully added to the inventory.\n\n");
		}
		fclose(fp); //Close the file
	}
	else {
		printf("File could not be opened!\n");
	}
}

void checkPrice(const char filename[], const int isbn2find)
{
	struct Book check;
	int flag = 0;
	int found = 0;

	FILE *fp = NULL;
	fp = fopen(filename, "r");
    //Open the file for reading
    
    //Type your code here
	if (fp != NULL) {
		found = searchInventory(fp, isbn2find);
		if (found == -1) {
			printf("The book does not in the repository!\n");
		}
		else {
			rewind(fp);
			while (flag == 0 && readRecord(fp, &check) == 5){
				if (found == check.isbn) {
					flag = 1;
				}
			}
			printf("Book %d costs %.2f\n\n", isbn2find, check.price);
		}
		fclose(fp);
	}
	else {
		printf("File could not be opened!");
	}//Close the file
 
}

int searchInventory(FILE *fp,const int isbn2find)
{
    //Define an object of struct Book and other necessary variables
	struct Book searchBook;
	int i = 0;
	int flag = 0;
	int found = 0;

    //If the file pointer is not NULL:
	if (fp != NULL) {
		//as long as the record is not found,
		//use the function readRecord to read the recods and look for isbn2find
		while (flag == 0 && readRecord(fp, &searchBook) == 5) {
			if (isbn2find == searchBook.isbn) {
				flag = 1;
			}
		}
	}
	else {
		printf("File could not be read!\n");
	}

	if (flag == 1) {
		return searchBook.isbn;
	}
	else {
		return -1;
	}
}

float calculateCapital(const char filename[])
{
	//Define an object of struct Book
	struct Book book;

	//Define and initialize total_capital
	float total_capital = 0;

	//Open the file, and check for null pointer
	FILE *fp = NULL;
	fp = fopen(filename, "r");

	//If the file is properly opened, use a while loop to call readRecord
	if (fp != NULL) {
		while (readRecord(fp, &book) == 5) {
			//Accumulate the multiplication of the price of each item to its quantity
			total_capital = total_capital + (book.price * book.qty);
		}
	}

	//Close the file
	fclose(fp);

	//return the total_capital
	return total_capital;
}

int readRecord(FILE *fp, struct Book *b2read)
{
	int rv = 0;//Define a variable int rv = 0

	rv = fscanf(fp, "%d;%f;%d;%d;%20[^\n]\n", &b2read->isbn, &b2read->price, &b2read->year, &b2read->qty, b2read->title);

	return rv;
}
